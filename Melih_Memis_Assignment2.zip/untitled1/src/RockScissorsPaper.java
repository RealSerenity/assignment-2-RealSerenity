import javax.swing.JOptionPane;
public class RockScissorsPaper {
    public static void winner(int a , int b){
        if(a ==5) JOptionPane.showMessageDialog(null,"-->You lose-!!");
        else if (b ==5 )JOptionPane.showMessageDialog(null,"-->You win!!!");
    }
    public static String changer(int n) {  //random integerdan string alabilmek için
        String result;
        if (n < 4)
            result = "Rock";
        else if (4 <= n && n < 7)
            result = "Paper";
        else
            result = "Scissor";
        return result;
    }
    public static void main(String[] args) {
        int my_score = 0;
        int your_score = 0;
        String my_choice;
        int round_counter = 0;
        JOptionPane.showMessageDialog(null, "The first player who reaches 5 points wins.",
                "Let's start",JOptionPane.INFORMATION_MESSAGE);
        while (my_score != 5 && your_score != 5) {
            round_counter += 1;
            String input = JOptionPane.showInputDialog(null,"My Score: " + my_score +
                    "  Your Score: " + your_score + "\n Rock, Scissor or Paper?","Round: " +
                    round_counter, JOptionPane.INFORMATION_MESSAGE);
            int number;
            while (true) {
                number = (int) (Math.random() * 10);
                if (number != 0)break;}
            my_choice = changer(number);
            if(input.equals(my_choice)){
                JOptionPane.showMessageDialog(null,"It's a tie!");}
            System.out.println(my_choice);
            switch (input) {
                case "Rock":
                    if(my_choice.equals("Scissor")){
                        JOptionPane.showMessageDialog(null,"My answer was "+ my_choice +
                                "." + " Rock breaks Scissor. You win!" );
                        your_score += 1;}
                    else if(my_choice.equals("Paper")){
                        JOptionPane.showMessageDialog(null,"My answer was "+ my_choice +"."+
                                " Paper eats Rock. You lose!" );
                        my_score +=1;}
                    break;
                case "Scissor":
                    if(my_choice.equals("Rock")){
                        JOptionPane.showMessageDialog(null,"My answer was: "+ my_choice +"."+
                                " Rock breaks Scissor. You lose!");
                        my_score += 1;}
                    else if(my_choice.equals("Paper")){
                        JOptionPane.showMessageDialog(null,"My answer was: "+ my_choice +"."+
                                " Scissor cuts Paper. You win!");
                        your_score += 1;}
                    break;
                case "Paper":
                    if(my_choice.equals("Scissor")){
                        JOptionPane.showMessageDialog(null,"My answer was"+ my_choice +"."+
                                " Scissor cuts Paper. You lose!");
                        my_score += 1;}
                    else if(my_choice.equals("Rock")){
                        JOptionPane.showMessageDialog(null,"My answer was"+ my_choice +"."+
                                " Paper eats Rock. You win!");
                        your_score += 1;}
                    break;
            }
        }
        //b is your score a is my(pc)score
        winner(my_score,your_score);
    }
}